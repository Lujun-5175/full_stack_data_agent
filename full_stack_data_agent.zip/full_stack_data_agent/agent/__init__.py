"""Agent facade layer."""
