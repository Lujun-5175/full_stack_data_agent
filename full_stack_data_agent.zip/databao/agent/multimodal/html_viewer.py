"""Databao viewer module for displaying multimodal tabs in the browser."""

import contextlib
import json
import queue
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import TYPE_CHECKING, Any

from databao.agent.multimodal.utils import dataframe_to_csv

if TYPE_CHECKING:
    from databao.agent.core.thread import Thread


TEMPLATE_PATH = Path(__file__).parent.parent.parent / "client" / "out" / "multimodal-html" / "index.html"
DATA_PLACEHOLDER = "window.__DATA__ = null;"


class MultimodalHTTPRequestHandler(BaseHTTPRequestHandler):
    """
    Serves:
      - GET / -> redirect to /<html_path>
      - GET /<html_path> -> returns HTML bytes (self.html_bytes)
      - GET /events -> Server-Sent Events that report spec generation progress
    """

    thread: "Thread"
    html_bytes: bytes
    html_path: str
    shutdown_event: threading.Event

    def do_GET(self) -> None:
        path = self.path.split("?", 1)[0]
        expected = f"/{self.html_path.lstrip('/')}"
        if path == expected:
            self.handle_html()
        elif path == "/events":
            self.handle_events()
        elif path == "/":
            self.send_response(302)
            self.send_header("Location", expected)
            self.end_headers()
        else:
            self.send_error(404, "Not Found")

    def handle_html(self) -> None:
        try:
            body = getattr(self, "html_bytes", b"")
            if not isinstance(body, (bytes, bytearray)):
                body = str(body).encode("utf-8")

            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()

            try:
                self.wfile.write(body)
                self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError):
                return
        except Exception:
            with contextlib.suppress(Exception):
                self.finish()

    def handle_events(self) -> None:
        try:
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache, no-transform")
            self.send_header("Connection", "keep-alive")
            self.end_headers()
        except Exception:
            self.shutdown_event.set()
            return

        result_queue: queue.Queue[Any] = queue.Queue()

        def _send_sse(data: dict[str, Any] | None = None, event: str | None = None) -> bool:
            try:
                payload_lines = []
                if event:
                    payload_lines.append(f"event: {event}")
                if data is not None:
                    # SSE 'data:' lines can be multi-line; ensure JSON fits on one line.
                    payload_lines.append(f"data: {json.dumps(data, separators=(',', ':'))}")
                else:
                    payload_lines.append("data: ")
                payload = "\n".join(payload_lines) + "\n\n"
                self.wfile.write(payload.encode("utf-8"))
                self.wfile.flush()
                return True
            except (BrokenPipeError, ConnectionResetError):
                return False
            except Exception:
                return False

        def generate_spec_worker() -> None:
            """
            Worker that computes the visualization spec and puts the spec or an Exception into result_queue.
            """
            try:
                plot = self.thread.plot()

                png_bytes = getattr(plot, "png_bytes", None)
                if not callable(png_bytes):
                    raise ValueError(f"Plot requires a PNG-capable chart result, got {type(plot).__name__}")
                image_bytes = png_bytes()
                if not image_bytes:
                    raise ValueError("Failed to generate visualization")
                result = {"imageBytesHex": image_bytes.hex(), "csvData": dataframe_to_csv(self.thread.df())}

                result_queue.put(result)

            except Exception as exc:
                result_queue.put(exc)

        spec_thread = threading.Thread(target=generate_spec_worker, daemon=True)

        """
        The SSE protocol:
        - send repeated {"type":"GENERATE_SPEC","status":"loading",...} while worker is alive
        - on success send {"type":"GENERATE_SPEC","status":"loaded","data": "<json-string>"}
        - on failure send {"type":"GENERATE_SPEC","status":"failed","error": "<message>"}
        - send a named SSE event "close" (no payload) to let client clean up
        """

        try:
            spec_thread.start()

            while spec_thread.is_alive():
                alive = _send_sse(
                    {
                        "type": "GENERATE_SPEC",
                        "status": "loading",
                        "error": "",
                        "data": "",
                    }
                )
                if not alive:
                    return
                time.sleep(0.1)

            try:
                result = result_queue.get_nowait()
            except queue.Empty as err:
                raise RuntimeError("Spec worker finished without producing a result") from err

            if isinstance(result, Exception):
                raise result

            try:
                data_str = json.dumps(result, separators=(",", ":"))
            except Exception as err:
                raise RuntimeError("Spec is not serializable") from err

            _send_sse(
                {
                    "type": "GENERATE_SPEC",
                    "status": "loaded",
                    "error": "",
                    "data": data_str,
                }
            )
        except Exception as exc:
            with contextlib.suppress(Exception):
                _send_sse(
                    {
                        "type": "GENERATE_SPEC",
                        "status": "failed",
                        "error": str(exc),
                        "data": "",
                    }
                )
        finally:
            _send_sse(event="close", data=None)
            self.shutdown_event.set()

    def log_message(self, format: str, *args: Any) -> None:
        return


def open_html_content(thread: "Thread") -> str:
    """Create an HTML file with the embedded chart content and open it in the browser.

    This function starts a temporary HTTP server, opens the HTML content in the browser,
    and closes the server after chart generation.

    Args:
        thread: The databao thread.

    Returns:
        The URL that was opened in the browser.

    Raises:
        FileNotFoundError: If the template file is not found.
    """

    if not TEMPLATE_PATH.exists():
        raise FileNotFoundError(
            f"Template file not found at {TEMPLATE_PATH}. "
            "This usually means the frontend wasn't built during installation. "
            "If you installed from pip, please report this as a bug."
        )

    df = thread.df()
    df_csv = dataframe_to_csv(df) if df is not None else ""

    data_object = {"text": thread.text(), "dataframeCsvContent": df_csv}
    data_json = json.dumps(data_object)

    template = TEMPLATE_PATH.read_text(encoding="utf-8")
    html = template.replace(DATA_PLACEHOLDER, f"window.__DATA__ = {data_json};")
    html_bytes = html.encode("utf-8")

    shutdown_event = threading.Event()

    MultimodalHTTPRequestHandler.thread = thread
    MultimodalHTTPRequestHandler.html_bytes = html_bytes
    MultimodalHTTPRequestHandler.html_path = _generate_short_id()
    MultimodalHTTPRequestHandler.shutdown_event = shutdown_event

    server = HTTPServer(("127.0.0.1", 0), MultimodalHTTPRequestHandler)
    port = server.server_port
    url = f"http://127.0.0.1:{port}/"

    server_thread = threading.Thread(target=server.serve_forever, daemon=True)
    server_thread.start()

    webbrowser.open(url, new=2, autoraise=True)

    shutdown_event.wait()
    server.shutdown()
    server.server_close()

    return url


def _generate_short_id() -> str:
    import uuid

    return uuid.uuid4().hex[:8]
