import json
from typing import Annotated, Any, Literal

import pandas as pd
from duckdb import DuckDBPyConnection
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_core.tools import BaseTool, tool
from langgraph.constants import END, START
from langgraph.graph import add_messages
from langgraph.graph.state import CompiledStateGraph, StateGraph
from langgraph.prebuilt import InjectedState
from typing_extensions import TypedDict

from databao.agent.configs import llm
from databao.agent.configs.agent import AgentConfig
from databao.agent.configs.llm import LLMConfig
from databao.agent.core import Domain, ExecutionResult
from databao.agent.executors.langchain_tools import make_search_context_tool
from databao.agent.executors.llm import call_model_with_retry, chat, model_bind_tools
from databao.agent.sql.guardrail import SqlGuardrail
from databao.agent.executors.utils import exception_to_string
from databao.agent.executors.utils import run_sql_query as _run_sql_query

RUN_SQL_QUERY_TOOL_DESCRIPTION = """\
Run a SELECT SQL query in the database. Returns the first 12 rows in csv format.

Args:
    sql: SQL query
"""


class AgentState(TypedDict):
    messages: Annotated[list[BaseMessage], add_messages]
    query_ids: dict[str, ToolMessage]
    sql: str | None
    df: pd.DataFrame | None
    visualization_prompt: str | None
    ready_for_user: bool
    limit_max_rows: int | None
    guardrail_failures: int
    guardrail_stop_reason: str | None
    query_obligations: dict[str, Any] | None
    sql_retry_history: list[dict[str, Any]]
    parsed_sql_summary: dict[str, Any] | None
    execution_validation_report: dict[str, Any] | None
    final_guardrail_status: str | None
    repair_attempts: list[dict[str, Any]]


def get_query_ids_mapping(messages: list[BaseMessage]) -> dict[str, ToolMessage]:
    query_ids = {}
    for message in messages:
        if isinstance(message, ToolMessage) and isinstance(message.artifact, dict) and "query_id" in message.artifact:
            query_ids[message.artifact["query_id"]] = message
    return query_ids


class ExecuteSubmit:
    """Simple graph with two tools: run_sql_query and submit_result.
    All context must be in the SystemMessage."""

    DISPLAY_ROW_LIMIT = 12
    """Max number of rows to return in SQL tool calls."""

    DISPLAY_CELL_CHAR_LIMIT = 1024
    """Max number of characters a dataframe cell can have before it is trimmed."""

    def __init__(self, connection: DuckDBPyConnection):
        self._connection = connection
        self._guardrail = SqlGuardrail(max_retries=3, llm_call=None)

    def _make_query_frame_llm_call(self, model_config: LLMConfig) -> Any:
        model = model_config.new_chat_model()

        def _call(prompt: str) -> str:
            messages = [
                SystemMessage(
                    content=(
                        "You produce strict JSON semantic query frames for SQL grounding. "
                        "Return JSON only and never guess final schema bindings."
                    )
                ),
                HumanMessage(content=str(prompt)),
            ]
            response = call_model_with_retry(model, messages)
            raw_text = getattr(response, "content", response)
            if isinstance(raw_text, list):
                raw_text = "\n".join(str(item.get("text", item)) if isinstance(item, dict) else str(item) for item in raw_text)
            return str(raw_text)

        return _call

    def init_state(self, messages: list[BaseMessage], *, limit_max_rows: int | None = None) -> AgentState:
        return AgentState(
            messages=messages,
            query_ids=get_query_ids_mapping(messages),
            sql=None,
            df=None,
            visualization_prompt=None,
            ready_for_user=False,
            limit_max_rows=limit_max_rows,
            guardrail_failures=0,
            guardrail_stop_reason=None,
            query_obligations=None,
            sql_retry_history=[],
            parsed_sql_summary=None,
            execution_validation_report=None,
            final_guardrail_status=None,
            repair_attempts=[],
        )

    def get_result(self, state: AgentState) -> ExecutionResult:
        stop_reason = state.get("guardrail_stop_reason")
        if stop_reason:
            return ExecutionResult(
                text=stop_reason,
                df=state.get("df"),
                code=state.get("sql", ""),
                meta={
                    "visualization_prompt": state.get("visualization_prompt"),
                    ExecutionResult.META_MESSAGES_KEY: state["messages"],
                    "submit_called": False,
                    "guardrail_stop_reason": stop_reason,
                    "query_obligations": state.get("query_obligations"),
                    "sql_retry_history": state.get("sql_retry_history", []),
                    "parsed_sql_summary": state.get("parsed_sql_summary"),
                    "execution_validation_report": state.get("execution_validation_report"),
                    "final_guardrail_status": state.get("final_guardrail_status"),
                    "repair_attempts": state.get("repair_attempts", []),
                },
            )

        last_ai_message = None
        for m in reversed(state["messages"]):
            if isinstance(m, AIMessage):
                last_ai_message = m
                break
        if last_ai_message is None:
            raise RuntimeError("No AI message found in message log")
        if len(last_ai_message.tool_calls) == 0:
            # Sometimes models don't call the submit_result tool, but we still want to return some dataframe.
            sql = state.get("sql", "")
            df = state.get("df")  # Latest df result (usually from run_sql_query)
            visualization_prompt = state.get("visualization_prompt")
            result = ExecutionResult(
                text=last_ai_message.text,
                df=df,
                code=sql,
                meta={
                    "visualization_prompt": visualization_prompt,
                    ExecutionResult.META_MESSAGES_KEY: state["messages"],
                    "submit_called": False,
                    "query_obligations": state.get("query_obligations"),
                    "sql_retry_history": state.get("sql_retry_history", []),
                    "parsed_sql_summary": state.get("parsed_sql_summary"),
                    "execution_validation_report": state.get("execution_validation_report"),
                    "final_guardrail_status": state.get("final_guardrail_status"),
                    "repair_attempts": state.get("repair_attempts", []),
                },
            )
        elif len(last_ai_message.tool_calls) > 1:
            raise RuntimeError("Expected exactly one tool call in AI message")
        elif last_ai_message.tool_calls[0]["name"] != "submit_result":
            raise RuntimeError(
                f"Expected submit_result tool call in AI message, got {last_ai_message.tool_calls[0]['name']}"
            )
        else:
            sql = state.get("sql", "")
            df = state.get("df")
            tool_call = last_ai_message.tool_calls[0]
            text = tool_call["args"]["result_description"]
            visualization_prompt = state.get("visualization_prompt", "")
            result = ExecutionResult(
                text=text,
                df=df,
                code=sql,
                meta={
                    "visualization_prompt": visualization_prompt,
                    ExecutionResult.META_MESSAGES_KEY: state["messages"],
                    "submit_called": True,
                    "query_obligations": state.get("query_obligations"),
                    "sql_retry_history": state.get("sql_retry_history", []),
                    "parsed_sql_summary": state.get("parsed_sql_summary"),
                    "execution_validation_report": state.get("execution_validation_report"),
                    "final_guardrail_status": state.get("final_guardrail_status"),
                    "repair_attempts": state.get("repair_attempts", []),
                },
            )
        return result

    def has_search_context_tool(self, domain: Domain) -> bool:
        return make_search_context_tool(domain) is not None

    def make_tools(self, domain: Domain, extra_tools: list[BaseTool] | None = None) -> list[BaseTool]:
        @tool(description=RUN_SQL_QUERY_TOOL_DESCRIPTION)
        def run_sql_query(sql: str, graph_state: Annotated[AgentState, InjectedState]) -> dict[str, Any]:
            query = self._guardrail.latest_user_query(graph_state.get("messages", []))
            schema = self._guardrail.schema_from_connection(self._connection)
            report = self._guardrail.validate_before_execution(query=query, sql=sql, schema=schema)
            if report.blocked:
                payload = self._guardrail.to_retry_error_payload(
                    report,
                    attempt=int(graph_state.get("guardrail_failures", 0)) + 1,
                    max_attempts=self._guardrail.max_retries,
                )
                return {
                    "error": self._guardrail.to_retry_error_text(payload),
                    "error_type": "sql_guardrail",
                    "guardrail": payload,
                    "sql": sql,
                }
            return _run_sql_query(
                sql,
                con=self._connection,
                sql_row_limit=graph_state["limit_max_rows"],
                display_row_limit=self.DISPLAY_ROW_LIMIT,
                display_cell_char_limit=self.DISPLAY_CELL_CHAR_LIMIT,
            )

        @tool(parse_docstring=True)
        def submit_result(
            query_id: str,
            result_description: str,
            visualization_prompt: str,
        ) -> str:
            """
            Call this tool with the ID of the query you want to submit to the user.
            This will return control to the user and must always be the last tool call.
            The user will see the full query result, not just the first 12 rows. Returns a confirmation message.

            Args:
                query_id: The ID of the query to submit (query_ids are automatically generated when you run queries).
                result_description: A comment to a final result. This will be included in the final result.
                visualization_prompt: Optional visualization prompt. If not empty, the chart visualizer
                    will be asked to plot the submitted query data according to instructions in the prompt.
                    The instructions should be short and simple.
            """
            return f"Query {query_id} submitted successfully. Your response is now visible to the user."

        tools: list[BaseTool] = [run_sql_query, submit_result]
        search_context_tool = make_search_context_tool(domain)
        if search_context_tool is not None:
            tools.append(search_context_tool)

        if extra_tools:
            tools.extend(extra_tools)

        return tools

    def compile(
        self,
        model_config: LLMConfig,
        agent_config: AgentConfig,
        domain: Domain,
        extra_tools: list[BaseTool] | None = None,
    ) -> CompiledStateGraph[Any]:
        self._guardrail = SqlGuardrail(max_retries=3, llm_call=self._make_query_frame_llm_call(model_config))
        tools = self.make_tools(domain, extra_tools=extra_tools)
        llm_model = model_config.new_chat_model()

        if llm.is_openai_model(model_config.name):
            # Only OpenAI models support parallel tool calls parameter
            model_with_tools = model_bind_tools(llm_model, tools, parallel_tool_calls=agent_config.parallel_tool_calls)
        else:
            model_with_tools = model_bind_tools(llm_model, tools)

        def llm_node(state: AgentState) -> dict[str, Any]:
            messages = state["messages"]
            response = chat(messages, model_config, model_with_tools)
            return {"messages": [response[-1]]}

        def tool_executor_node(state: AgentState) -> dict[str, Any]:
            last_message = state["messages"][-1]
            tool_messages = []
            assert isinstance(last_message, AIMessage)

            tool_calls = last_message.tool_calls

            is_ready_for_user = any(tc["name"] == "submit_result" for tc in tool_calls)
            if is_ready_for_user:
                if len(tool_calls) > 1:
                    tool_messages = [
                        ToolMessage("submit_result must be the only tool call.", tool_call_id=tool_call["id"])
                        for tool_call in tool_calls
                    ]
                    return {"messages": tool_messages, "ready_for_user": False}
                else:
                    tool_call = tool_calls[0]

                    if "query_ids" not in state or len(state["query_ids"]) == 0:
                        tool_messages = [
                            ToolMessage("No queries have been executed yet.", tool_call_id=tool_call["id"])
                        ]
                        return {"messages": tool_messages, "ready_for_user": False}

                    query_id = tool_call["args"]["query_id"]
                    if query_id not in state["query_ids"]:
                        available_ids = ", ".join(state["query_ids"].keys())
                        tool_messages = [
                            ToolMessage(
                                f"Query ID {query_id} not found. Available query IDs: {available_ids}",
                                tool_call_id=tool_call["id"],
                            )
                        ]
                        return {"messages": tool_messages, "ready_for_user": False}

                    target_tool_message = state["query_ids"][query_id]
                    if target_tool_message.artifact is None or "df" not in target_tool_message.artifact:
                        tool_messages = [
                            ToolMessage(f"Query {query_id} does not have a valid result.", tool_call_id=tool_call["id"])
                        ]
                        return {"messages": tool_messages, "ready_for_user": False}

            query_ids = dict(state.get("query_ids", {}))
            sql = state.get("sql")
            df = state.get("df")
            visualization_prompt = state.get("visualization_prompt", "")
            guardrail_failures = int(state.get("guardrail_failures", 0))
            guardrail_stop_reason = state.get("guardrail_stop_reason")
            query_obligations = state.get("query_obligations")
            sql_retry_history = list(state.get("sql_retry_history", []))
            parsed_sql_summary = state.get("parsed_sql_summary")
            execution_validation_report = state.get("execution_validation_report")
            final_guardrail_status = state.get("final_guardrail_status")
            repair_attempts = list(state.get("repair_attempts", []))

            message_index = len(state["messages"]) - 1

            for idx, tool_call in enumerate(tool_calls):
                name = tool_call["name"]
                args = tool_call["args"]
                tool_call_id = tool_call["id"]
                # Find the tool by name
                tool = next((t for t in tools if t.name == name), None)
                if tool is None:
                    tool_messages.append(ToolMessage(content=f"Tool {name} does not exist!", tool_call_id=tool_call_id))
                    continue

                try:
                    result = tool.invoke(args | {"graph_state": state})
                except Exception as e:
                    result = {"error": exception_to_string(e) + f"\nTool: {name}, Args: {args}"}

                content = ""
                if name == "run_sql_query":
                    sql = result.get("sql")
                    df = result.get("df")
                    if result.get("error_type") == "sql_guardrail":
                        guard_payload = dict(result.get("guardrail") or {})
                        guard_report = dict(guard_payload.get("report") or {})
                        if query_obligations is None:
                            query_obligations = guard_report.get("obligations")
                        parsed_sql_summary = guard_report.get("parsed_sql_summary") or parsed_sql_summary
                        execution_validation_report = guard_report.get("execution_validation_report") or execution_validation_report
                        final_guardrail_status = guard_report.get("final_guardrail_status") or (guard_report.get("guardrail_report") or {}).get("status") or final_guardrail_status
                        sql_retry_history.append(
                            {
                                "attempt": guard_payload.get("attempt"),
                                "max_attempts": guard_payload.get("max_attempts"),
                                "report": guard_report,
                            }
                        )
                        repair_attempts = list(guard_report.get("repair_attempts") or repair_attempts)
                        guardrail_failures += 1
                        if guardrail_failures >= self._guardrail.max_retries:
                            guardrail_stop_reason = (
                                "SQL guardrail blocked query generation after "
                                f"{self._guardrail.max_retries} attempts. "
                                "Please revise the SQL constraints or prompt."
                            )
                    # Generate query_id using message index and tool call index
                    query_id = f"{message_index}-{idx}"
                    # Override the query_id in the result
                    result["query_id"] = query_id
                    content = result.get("csv", result.get("error", ""))
                    if "csv" in result:
                        content = f"query_id='{query_id}'\n\n{content}"
                    if query_id:
                        query_ids[query_id] = ToolMessage(
                            content=content,
                            tool_call_id=tool_call_id,
                            artifact=result,
                        )
                elif name == "submit_result":
                    query_id = tool_call["args"]["query_id"]
                    visualization_prompt = tool_call["args"].get("visualization_prompt", "")
                    sql = state["query_ids"][query_id].artifact["sql"]
                    df = state["query_ids"][query_id].artifact["df"]
                    query = self._guardrail.latest_user_query(state.get("messages", []))
                    schema = self._guardrail.schema_from_connection(self._connection)
                    post_report = self._guardrail.validate_after_execution(
                        query=query,
                        sql=sql,
                        dataframe=df,
                        schema=schema,
                    )
                    if post_report.blocked:
                        guardrail_failures += 1
                        payload = self._guardrail.to_retry_error_payload(
                            post_report,
                            attempt=guardrail_failures,
                            max_attempts=self._guardrail.max_retries,
                        )
                        if query_obligations is None:
                            query_obligations = (payload.get("report") or {}).get("obligations")
                        parsed_sql_summary = post_report.parsed_sql_summary or parsed_sql_summary
                        execution_validation_report = post_report.execution_validation_report or execution_validation_report
                        final_guardrail_status = post_report.final_guardrail_status or final_guardrail_status
                        sql_retry_history.append(
                            {
                                "attempt": payload.get("attempt"),
                                "max_attempts": payload.get("max_attempts"),
                                "report": payload.get("report"),
                            }
                        )
                        repair_attempts = list(post_report.repair_attempts or repair_attempts)
                        result = {
                            "error": self._guardrail.to_retry_error_text(payload),
                            "error_type": "sql_guardrail",
                            "guardrail": payload,
                            "sql": sql,
                        }
                        content = result["error"]
                        if guardrail_failures >= self._guardrail.max_retries:
                            guardrail_stop_reason = (
                                "SQL guardrail blocked submit_result after "
                                f"{self._guardrail.max_retries} attempts. "
                                "Please revise the SQL constraints or prompt."
                            )
                    else:
                        content = str(result)
                else:
                    if isinstance(result, dict):
                        content = json.dumps(result, ensure_ascii=False, default=str)
                    else:
                        content = str(result)
                tool_messages.append(ToolMessage(content=content, tool_call_id=tool_call_id, artifact=result))
                if name == "submit_result":
                    if isinstance(result, dict) and result.get("error_type") == "sql_guardrail":
                        return {
                            "messages": tool_messages,
                            "query_ids": query_ids,
                            "sql": sql,
                            "df": df,
                            "visualization_prompt": visualization_prompt,
                            "ready_for_user": bool(guardrail_stop_reason),
                            "guardrail_failures": guardrail_failures,
                            "guardrail_stop_reason": guardrail_stop_reason,
                            "query_obligations": query_obligations,
                            "sql_retry_history": sql_retry_history,
                            "parsed_sql_summary": parsed_sql_summary,
                            "execution_validation_report": execution_validation_report,
                            "final_guardrail_status": final_guardrail_status,
                            "repair_attempts": repair_attempts,
                        }
                    return {
                        "messages": tool_messages,
                        "sql": sql,
                        "df": df,
                        "visualization_prompt": visualization_prompt,
                        "ready_for_user": True,
                        "guardrail_failures": guardrail_failures,
                        "guardrail_stop_reason": guardrail_stop_reason,
                        "query_obligations": query_obligations,
                        "sql_retry_history": sql_retry_history,
                        "parsed_sql_summary": parsed_sql_summary,
                        "execution_validation_report": execution_validation_report,
                        "final_guardrail_status": final_guardrail_status,
                        "repair_attempts": repair_attempts,
                    }
            return {
                "messages": tool_messages,
                "query_ids": query_ids,
                "sql": sql,
                "df": df,
                "visualization_prompt": visualization_prompt,
                "ready_for_user": False,
                "guardrail_failures": guardrail_failures,
                "guardrail_stop_reason": guardrail_stop_reason,
                "query_obligations": query_obligations,
                "sql_retry_history": sql_retry_history,
                "parsed_sql_summary": parsed_sql_summary,
                "execution_validation_report": execution_validation_report,
                "final_guardrail_status": final_guardrail_status,
                "repair_attempts": repair_attempts,
            }

        def should_continue(state: AgentState) -> Literal["tool_executor", "end"]:
            # Check if there are tool calls in the last message
            last_message = state["messages"][-1]
            if isinstance(last_message, AIMessage) and last_message.tool_calls:
                return "tool_executor"
            return "end"

        def should_finish(state: AgentState) -> Literal["llm_node", "end"]:
            # Check if we just executed submit_result - if so, end the conversation
            if state.get("ready_for_user", False):
                return "end"
            return "llm_node"

        graph = StateGraph(AgentState)
        graph.add_node("llm_node", llm_node)
        graph.add_node("tool_executor", tool_executor_node)

        graph.add_edge(START, "llm_node")
        graph.add_conditional_edges("llm_node", should_continue, {"tool_executor": "tool_executor", "end": END})
        graph.add_conditional_edges("tool_executor", should_finish, {"llm_node": "llm_node", "end": END})
        return graph.compile()
