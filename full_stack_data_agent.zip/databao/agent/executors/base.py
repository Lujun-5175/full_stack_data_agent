﻿import logging
from abc import ABC, abstractmethod
from collections.abc import Callable
from typing import Any, TextIO

import duckdb
from langchain_core.messages import BaseMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_core.runnables import RunnableConfig
from langchain_core.tools import BaseTool
from langgraph.graph.state import CompiledStateGraph

from databao.agent.configs.agent import AgentConfig
from databao.agent.configs.llm import LLMConfig
from databao.agent.core import Cache
from databao.agent.core.data_source import DBDataSource, DBTDataSource, DFDataSource, Sources
from databao.agent.core.domain import Domain, _Domain
from databao.agent.core.executor import ExecutionResult, Executor, OutputModalityHints
from databao.agent.core.opa import Opa
from databao.agent.databases import register_db_in_duckdb
from databao.agent.executors.frontend.text_frontend import TextStreamFrontend
from databao.agent.executors.history_cleaning import clean_tool_history

logger = logging.getLogger(__name__)



_EXPLICIT_VISUALIZATION_MARKERS = (
    "plot",
    "chart",
    "graph",
    "visual",
    "visualize",
    "visualization",
    "histogram",
    "scatter",
    "bar chart",
    "line chart",
    "heatmap",
    "box plot",
    "distribution",
    "画图",
    "绘图",
    "图表",
    "分布图",
    "直方图",
    "散点图",
    "热力图",
    "柱状图",
    "折线图",
    "箱线图",
)

_RESULT_REUSE_MARKERS = (
    "不要重新筛选",
    "不要重新聚合",
    "同一个结果",
    "同一批",
    "基于刚才",
    "same result",
    "same grouped result",
    "do not re-filter",
    "don't re-filter",
    "do not regroup",
    "don't regroup",
)


class DuckDBExecutor(Executor, ABC):
    """Base class for executors that run against DuckDB."""

    def __init__(self, writer: TextIO | None = None) -> None:
        self._writer = writer
        self._duckdb_connection: duckdb.DuckDBPyConnection = duckdb.connect(":memory:")
        self._registered_dbs: dict[str, DBDataSource] = {}
        self._registered_dfs: dict[str, DFDataSource] = {}
        self._registered_dbts: dict[str, DBTDataSource] = {}

    def _init_sources_from_domain(self, domain: Domain, *, register_in_duckdb: bool = True) -> None:
        if not isinstance(domain, _Domain):
            return

        sources: Sources = domain.sources

        for name, db_source in sources.dbs.items():
            if name not in self._registered_dbs:
                if register_in_duckdb:
                    try:
                        register_db_in_duckdb(self._duckdb_connection, db_source.config, name)
                    except Exception as exc:
                        logger.warning("Datasource '%s' is not available and will be skipped: %s", name, exc)
                        continue
                self._registered_dbs[name] = db_source

        for name, df_source in sources.dfs.items():
            if name not in self._registered_dfs:
                if register_in_duckdb:
                    self._duckdb_connection.register(name, df_source.df)
                self._registered_dfs[name] = df_source

        for name, dbt_source in sources.dbts.items():
            if name not in self._registered_dbts:
                self._registered_dbts[name] = dbt_source


class GraphExecutor(DuckDBExecutor, ABC):
    """Base class for LangGraph executors that share common graph execution helpers."""

    def __init__(self, writer: TextIO | None = None) -> None:
        super().__init__(writer)
        self._extra_tools: dict[str, BaseTool] = {}
        self._graph_recursion_limit = 50
        self._compiled_graph: CompiledStateGraph[Any] | None = None
        self._compiled_tools_version: int = 0
        self._compiled_at_version: int = -1

    def register_tools(self, tools: list[BaseTool]) -> None:
        for t in tools:
            self._extra_tools[t.name] = t
        self._compiled_tools_version += 1

    def drop_last_opa_group(self, cache: Cache, n: int = 1) -> None:
        messages = cache.get("state", default={}).get("messages", [])
        human_messages = [m for m in messages if isinstance(m, HumanMessage)]
        if len(human_messages) < n:
            raise ValueError(f"Cannot drop last {n} operations - only {len(human_messages)} operations found.")
        c = 0
        while c < n:
            m = messages.pop()
            if isinstance(m, HumanMessage):
                c += 1

    @abstractmethod
    def _compile_graph(
        self,
        llm_config: LLMConfig,
        agent_config: AgentConfig,
        domain: Domain,
        extra_tools: list[BaseTool] | None,
    ) -> CompiledStateGraph[Any]:
        """Build and return a fresh compiled graph."""

    def _get_compiled_graph(
        self, llm_config: LLMConfig, agent_config: AgentConfig, domain: Domain
    ) -> CompiledStateGraph[Any]:
        if self._compiled_graph is None or self._compiled_at_version != self._compiled_tools_version:
            extra = list(self._extra_tools.values()) or None
            self._compiled_graph = self._compile_graph(llm_config, agent_config, domain, extra)
            self._compiled_at_version = self._compiled_tools_version
        return self._compiled_graph

    def _process_opas(self, opas: list[Opa], cache: Cache) -> list[Any]:
        messages: list[Any] = cache.get("state", {}).get("messages", [])
        query = "\n\n".join(opa.query for opa in opas)
        messages.append(HumanMessage(content=query))
        return messages

    def _execute_core(
        self,
        opas: list[Opa],
        cache: Cache,
        llm_config: LLMConfig,
        agent_config: AgentConfig,
        domain: Domain,
        *,
        system_prompt: str,
        init_state: Any,
        get_result: Callable[[Any], ExecutionResult],
        extra_preamble: list[Any] | None = None,
        stream: bool = True,
        writer: TextIO | None = None,
    ) -> tuple[ExecutionResult, Any]:
        compiled_graph = self._get_compiled_graph(llm_config, agent_config, domain)
        messages: list[Any] = self._process_opas(opas, cache)
        cached_state = cache.get("state", {})

        all_messages_with_system = self._ensure_system_message(messages, system_prompt, extra_preamble)
        last_user_query = opas[-1].query if opas else ""
        if self._looks_like_result_reuse_request(last_user_query):
            cleaned_messages = all_messages_with_system.copy()
        else:
            cleaned_messages = clean_tool_history(all_messages_with_system, llm_config.max_tokens_before_cleaning)

        if isinstance(init_state, dict):
            init_state["messages"] = cleaned_messages
            if "query_ids" in init_state:
                query_ids = dict(cached_state.get("query_ids", {}))
                query_ids.update(self._collect_query_ids(cleaned_messages))
                init_state["query_ids"] = query_ids
        else:
            init_state = {**init_state, "messages": cleaned_messages}

        invoke_config = self._build_invoke_config(agent_config, opas)
        last_state = self._invoke_graph_sync(
            compiled_graph, init_state, config=invoke_config, stream=stream, writer=writer or self._writer
        )

        execution_result = get_result(last_state)
        all_messages_without_system, all_messages = self._reconcile_messages(
            all_messages_with_system, cleaned_messages, last_state
        )
        if all_messages:
            if execution_result.meta.get(ExecutionResult.META_MESSAGES_KEY):
                execution_result.meta[ExecutionResult.META_MESSAGES_KEY] = all_messages
            self._update_message_history(cache, all_messages_without_system)

        execution_result.meta[OutputModalityHints.META_KEY] = self._make_output_modality_hints(execution_result)
        return execution_result, last_state

    @staticmethod
    def _collect_query_ids(messages: list[BaseMessage]) -> dict[str, ToolMessage]:
        query_ids: dict[str, ToolMessage] = {}
        for message in messages:
            if isinstance(message, ToolMessage) and isinstance(message.artifact, dict) and "query_id" in message.artifact:
                query_id = str(message.artifact["query_id"])
                if query_id:
                    query_ids[query_id] = message
        return query_ids

    @staticmethod
    def _ensure_system_message(
        messages: list[BaseMessage],
        system_content: str,
        extra_preamble: list[BaseMessage] | None = None,
    ) -> list[BaseMessage]:
        if messages and messages[0].type == "system":
            return messages
        preamble: list[BaseMessage] = [SystemMessage(system_content)]
        if extra_preamble:
            preamble.extend(extra_preamble)
        return [*preamble, *messages]

    @staticmethod
    def _reconcile_messages(
        all_messages_with_system: list[BaseMessage],
        cleaned_messages: list[BaseMessage],
        last_state: dict[str, Any],
    ) -> tuple[list[BaseMessage], list[BaseMessage]]:
        final_messages = last_state.get("messages", [])
        if not final_messages:
            return [], []
        new_messages = final_messages[len(cleaned_messages) :]
        all_messages = all_messages_with_system + new_messages
        all_messages_without_system = [m for m in all_messages if m.type != "system"]
        return all_messages_without_system, all_messages

    def _update_message_history(self, cache: Cache, final_messages: list[Any]) -> None:
        if final_messages:
            cache.put("state", {"messages": final_messages, "query_ids": self._collect_query_ids(final_messages)})

    def _make_output_modality_hints(self, result: ExecutionResult) -> OutputModalityHints:
        vis_prompt = result.meta.get("visualization_prompt", None)
        if vis_prompt is not None and len(vis_prompt) == 0:
            vis_prompt = None

        df = result.df
        user_query = self._extract_last_user_query(result)
        should_visualize = bool(
            vis_prompt is not None
            and df is not None
            and len(df) >= 3
            and self._has_explicit_visualization_intent(user_query)
        )
        return OutputModalityHints(visualization_prompt=vis_prompt, should_visualize=should_visualize)

    @staticmethod
    def _extract_last_user_query(result: ExecutionResult) -> str:
        messages: list[Any] = result.meta.get(ExecutionResult.META_MESSAGES_KEY, [])
        for message in reversed(messages):
            if isinstance(message, HumanMessage):
                return str(message.content)
        return ""

    @staticmethod
    def _has_explicit_visualization_intent(user_query: str) -> bool:
        lowered_query = user_query.lower()
        return any(keyword in lowered_query for keyword in _EXPLICIT_VISUALIZATION_MARKERS)

    @staticmethod
    def _looks_like_result_reuse_request(user_query: str) -> bool:
        lowered_query = user_query.lower()
        return any(marker in lowered_query for marker in _RESULT_REUSE_MARKERS)

    @classmethod
    def _executor_tag(cls) -> str:
        name = cls.__name__
        if name.endswith("Executor"):
            name = name[: -len("Executor")]
        import re

        return re.sub(r"(?<=[a-z0-9])(?=[A-Z])", "-", name).lower()

    def _build_invoke_config(self, agent_config: AgentConfig, opas: list[Opa]) -> RunnableConfig:
        opa = opas[-1] if opas else None
        executor_tag = self._executor_tag()

        metadata: dict[str, Any] = {"executor": executor_tag}
        if opa:
            metadata["question"] = opa.query
            if opa.metadata:
                metadata.update(opa.metadata)

        tags = [executor_tag]
        if opa and opa.tags:
            tags.extend(opa.tags)

        return RunnableConfig(
            recursion_limit=max(self._graph_recursion_limit, agent_config.recursion_limit),
            metadata=metadata,
            tags=tags,
        )

    @staticmethod
    def _invoke_graph_sync(
        compiled_graph: CompiledStateGraph[Any],
        start_state: Any,
        *,
        config: RunnableConfig | None = None,
        stream: bool = True,
        writer: TextIO | None = None,
        **kwargs: Any,
    ) -> Any:
        if stream:
            return GraphExecutor._execute_stream_sync(compiled_graph, start_state, config=config, writer=writer, **kwargs)
        return compiled_graph.invoke(start_state, config=config)

    @staticmethod
    async def _execute_stream(
        compiled_graph: CompiledStateGraph[Any],
        start_state: Any,
        *,
        config: RunnableConfig | None = None,
        writer: TextIO | None = None,
        **kwargs: Any,
    ) -> Any:
        frontend = TextStreamFrontend(
            start_state,
            writer=writer,
            on_text_chunk=getattr(writer, "on_text_chunk", None),
        )
        last_state = None
        async for mode, chunk in compiled_graph.astream(
            start_state,
            stream_mode=["values", "messages"],
            config=config,
            **kwargs,
        ):
            frontend.write_stream_chunk(mode, chunk)
            if mode == "values":
                last_state = chunk
        frontend.end()
        if last_state is None:
            raise RuntimeError("Graph execution produced no output state")
        return last_state

    @staticmethod
    def _execute_stream_sync(
        compiled_graph: CompiledStateGraph[Any],
        start_state: Any,
        *,
        config: RunnableConfig | None = None,
        writer: TextIO | None = None,
        **kwargs: Any,
    ) -> Any:
        frontend = TextStreamFrontend(
            start_state,
            writer=writer,
            on_text_chunk=getattr(writer, "on_text_chunk", None),
        )
        last_state = None
        for mode, chunk in compiled_graph.stream(
            start_state,
            stream_mode=["values", "messages"],
            config=config,
            **kwargs,
        ):
            frontend.write_stream_chunk(mode, chunk)
            if mode == "values":
                last_state = chunk
        frontend.end()
        if last_state is None:
            raise RuntimeError("Graph execution produced no output state")
        return last_state
